/*
File Name: main.cpp
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This main.cpp file was developed for part a of the Wordsearch project. The main
objective of this file is to call the search global function, which goes
through and reads the name of the grid file from the keyboards, reads the data
from the input grid and dictionary, and prints out words that can be found in
the dictionary. An additional global function findMatches is used to print
candidate words that can be found in the dictionary.

NOTE: The implementation of the code follows the guidelines in the project
handout. However, the execution of SelectionSort algorithm on the sorting
of the dictionary will take a while. To simply the testing of this program,
comment out (Lines 38 & 428) and uncomment (Line 42).
*/


// Include statements
#include <iostream>
#include <fstream>
#include <stdlib.h>
#include <vector>
#include <string>

#include "grid.h"
#include "dictionary.h"

using namespace std;


// Constants to define input dictionary file
//const string DICTIONARY_FILE_NAME = "TestDictionary.txt";

// COMMENT BELOW TO TEST FUNCTIONALITY
const string DICTIONARY_FILE_NAME = "Dictionary.txt";
// COMMENT ABOVE TO TEST FUNCTIONALITY

// UNCOMMENT BELOW TO TEST FUNCTIONALITY
//const string DICTIONARY_FILE_NAME = "SortedDictionary.txt";
// UNCOMMENT ABOVE TO TEST FUNCTIONALITY


// Constant to define number of searching directions in grid
// Up, Down, Left, Right, UpRight, UpLeft, DownRight, DownLeft
const int NUMBER_GRID_DIRECTONS = 8;



void searchCandidateWord(const Dictionary& d, int wordPosInDict, 
						 string wordInGrid, int row, int col)
// Function which searches for a candidate word from the grid in the dictionary
// with BinarySearch (findWord function). If found and the word is of valid
// length, the word, starting letter position in the grid, and location in the
// dictionary are printed
{
	// BinarySearch function on the dictionary
	wordPosInDict = d.findWord(wordInGrid);

	if (wordPosInDict != -1 and wordInGrid.size() >= 5)
	// Checks if word is found in dictionary and has a legnth >= 5
	{
		cout << wordInGrid << "			" << row
			<< " " << col << "			"
			<< wordPosInDict << endl;
	}// End if
}// End searchCandidateWord() function


void traverseGrid(const Dictionary& d, const Grid& g, int currRow, 
				  int currCol, int row, int col, string wordInGrid, 
				  int switchCnt, int wordPosInDict, int nForGrid, int a)
{
	// Use switch to define all operations for 8 grid directions.
	// All cases have the same structure expect for the shifts carried out on
	// the columns and/or rows.
	// The switch case also passes the identified word to searchCandidateWord()
	// to see if the candidate word is in the dictionary of words
	switch (a)
	{
	// Right
	case 0:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			// Follows traversal technique for Right shift
			currCol++;

			if (currCol == nForGrid)
			{
				currCol = 0;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Left
	case 1:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currCol--;

			if (currCol == -1)
			{
				currCol = g.numCols() - 1;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Up
	case 2:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currRow--;

			if (currRow == -1)
			{
				currRow = g.numRows() - 1;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Down
	case 3:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currRow++;

			if (currRow == nForGrid)
			{
				currRow = 0;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Up Right
	case 4:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currRow--;
			currCol++;

			if (currRow == -1)
			{
				currRow = nForGrid - 1;
			}

			if (currCol == nForGrid)
			{
				currCol = 0;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Down Right
	case 5:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currRow++;
			currCol++;

			if (currRow == nForGrid)
			{
				currRow = 0;
			}

			if (currCol == nForGrid)
			{
				currCol = 0;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Up Left
	case 6:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currRow--;
			currCol--;

			if (currRow == -1)
			{
				currRow = nForGrid - 1;
			}

			if (currCol == -1)
			{
				currCol = nForGrid - 1;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;

	// Down Left
	case 7:
		switchCnt = 0;

		while (switchCnt != (nForGrid - 1))
		// While loop only runs for a maximum of n times (number of rows in
		// grid)
		{
			currRow++;
			currCol--;

			if (currRow == nForGrid)
			{
				currRow = 0;
			}

			if (currCol == -1)
			{
				currCol = nForGrid - 1;
			}

			// Returns grid character in specific location
			wordInGrid += g.returnGridChar(currRow, currCol);

			// Call searchCandidateWord to see if it exists in the dictionary
			searchCandidateWord(d, wordPosInDict, wordInGrid, row, col);

			// Advance counter
			switchCnt++;
		}// End while
		break;
	}

}// End traverseGrid() function


void findMatches(const Dictionary& d, const Grid& g)
{
	// Temporary int to store varied row and col values to find candidate words
	int currRow = 0, currCol = 0;

	// Counter for switch Case
	int switchCnt = 0;

	// Stores 'n' value of grid dimension for calculations
	// should be a 'n x n' grid, so does not matter if number of rows or number
	// of columns value is obtained
	int nForGrid = g.numRows();

	// Header information for data found in dictionary from candidate
	// words
	cout << "\nPrinting Words Found in Sorted Dictionary:\n";
	cout << "\nWord			(posRow, posCol)		Index in Sorted Dictionary"
		 << " (Starting from Index = 0)\n\n";

	for (int row = 0; row < g.numRows(); row++)
	// loop through each row of grid matrix
	{
		for (int col = 0; col < g.numCols(); col++)
		// loop through each col of grid matrix
		{
			// Get starting letter
			char currentLetter = g.returnGridChar(row, col);

			// String for storing candidate words; starting value is starting
			// letter
			string wordInGrid;

			// Stores location of word in dictionary if found (used in 
			// searchCandidateWord() function)
			int wordPosInDict = 0;

			for (int a = 0; a < NUMBER_GRID_DIRECTONS; a++)
			// Loop for each of the 8 directions to find all candidate words
			{
				// Assign temporary variables to current values in for loops
				currRow = row;
				currCol = col;

				// Clear wordInGrid variable to starting character
				wordInGrid = string(1, currentLetter);

				// Call traverseGrid() which contains logic for identifying
				// candidate words
				traverseGrid(d, g, currRow, currCol, row, col, wordInGrid, 
					         switchCnt, wordPosInDict, nForGrid, a);
			}
		}// End column for loop
	}// End row for loop
}// End findMatches() global function


void search()
// Reads name of grid file, reads data from grid and dictionary input files,
// and prints candidate words
{
	// Ftring to store input fielname
	string inputGridFile;

	// input file object
	ifstream fin;

	// Stores number of rows and columns of input grid
	int numRows = 0, numCols = 0;

	// Output to console to ask user to enter .txt filename
	// NOTE: This file must be located in the same directory as this C++ file
	cout << "Please enter the name of the Grid File that should be used. "
		 << "Please ensure file is located in same folder as this CPP file "
		 << "and contains the filename along with the .txt extension: ";

	cin >> inputGridFile;

	// Open input from inputGridFile
	fin.open(inputGridFile.c_str());

	while (!fin)
	// Error checking to see if input file is valid
	{
		// If not valid, user if forced to keep entering file until entry is
		// valid
		cout << "File name entered is not valid. Please try again: ";
		cin >> inputGridFile;

		fin.open(inputGridFile.c_str());
	}

	// Read # rows and columns from grid data
	fin >> numRows >> numCols;

	// Close grid file
	fin.close();

	// Instantiates dictionary and grid objects
	Dictionary wordDictionary;

	// Grid object that reads data into grid
	Grid currentGrid(numRows, numCols, inputGridFile);

	// Read dictionary into wordDictionary object
	wordDictionary.ReadIn(DICTIONARY_FILE_NAME);

	// Sort the dictionary
	// COMMENT BELOW TO TEST FUNCTIONALITY
	wordDictionary.selectionSort();
	// COMMENT ABOVE TO TEST FUNCTIONALITY

	// Prints complete dictionary
	//cout << wordDictionary;

	// Call findMatches to determine matches between grid and dictionary
	findMatches(wordDictionary, currentGrid);
}// End search() global function


int main()
{
	// Call search function
	search();

	return 0;
}// End main()

// End main.cpp