/*
File Name: dictionary.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This dictionary.h file was developed for part a of the Wordsearch project. This
file serves as a class that can read the words from the dictionary file
and store them in a vector.

This class contains:
- A function to read the owrds from the dictionary file
- An overloaded output operator to print the word list
- A function that sorts the words using selectionsort
- A function to hjandle word lookups using binary search
*/


// Definition for header file
#ifndef DICTIONARY_CLASS
#define DICTIONARY_CLASS

// Include statements
#include <iostream>
#include <strstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>
#include <fstream>


using namespace std;



class Dictionary
{
	// Public members of Dictionary Class
	public:
		//Function that reads in the dictionary txt document
		void ReadIn(string fileName);

		//Function that sorts the unsorted dictionary
		void selectionSort();

		//function that finds a word in the dictionary and returns
		//if the word is in the dictionary file
		int findWord(string WordChoice) const;

		// << operator overloading for Dictionary class to print the word 
		friend ostream& operator<< (ostream& ostr, const Dictionary& currentWord);

	// Private members of Dictionary Class
	private:
		//vector of strings to store the words from the dictionary file
		vector<string> words = {};
};


void Dictionary::ReadIn(string fileName)
//Reads whatever is in dictionary into a vector of strings
{
	ifstream inFile;

	//File name string being assigned to the txtfile
	//string filename = "TestDictionary.txt";
	//opens txt file
	inFile.open(fileName.c_str());

	//checks if the file is able to be opened
	if (!inFile) {
		cerr << "Unable to open file" << endl;
		exit(1);   // call system to stop
	}

	//reads in content of the file to two vector of strings
	//words is to be sorted and dict is the default
	string count;

	while (inFile >> count)
	{
		words.push_back(count);
	}

	//reads out the size of the dictionary
	cout << "\n\nSize of dictionary: " << words.size() << " word(s)\n";

	// Closes readin file
	inFile.close();

}// End ReadIn() function


void Dictionary::selectionSort()
//this function sorts the words vector of strings
//this function uses the selection sort algorithm
{
	//for loop that runs through the size of the words vector -1
	for (int i = 0; i < words.size() - 1; i++)
	{
		//low represents the lowest value in the vector of strings
		int low = i;

		//another for loop that goes through the same vector of strings but 
		//starts at a different point
		for (int j = i + 1; j < words.size(); j++)
		{
			//an if loop to compare two words in the same vector of strings
			//this if loop swaps the two words if words[j] is smaller then words[i]
			if (words[i] > words[j])
			{
				string temp;//temporary string to store a word for swapping
				temp = words[j];
				words[j] = words[i];
				words[i] = temp;
				low = i;
			}

		}// End for

		//opens text file to read sorted dictionary out too
		ofstream testFile;
		testFile.open("SortedDictFromFunction.txt");//name of text file

		for (int k = 0; k < words.size(); k++)//runs through sorted dictionary and
		//stored sorted words into document
		{
			testFile << words[k] << endl;
		}

		testFile.close();	//closes output file
	}

	cout << "Your dictionary has been sorted!" << endl;

}// End selectionSort() function


int Dictionary::findWord(string WordChoice) const
//function to determine if the word is in the dictionary
//needs word choice and sorted dictionary
{
	int firstWord = 0;//begining of window
	int lastWord = words.size() - 1;//end of window

	while (firstWord <= lastWord)//constantly checks the window
	{
		int middle = (firstWord + lastWord) / 2;//finds midpoint of window
		string MidWord = words[middle];//word at the middle of window

		if (WordChoice == MidWord)//if the words match
		{
			return middle;
		}
		else if (WordChoice < MidWord)
			lastWord = middle - 1;//if the word is before the midpoint
		//adjust the window to the first half
		else
			firstWord = middle + 1; //if the word is after the midpoint
		//adjust the window to the second half
	}
	return -1;
}// End findWord() function


//---------------------------------------------------------
ostream& operator<< (ostream& ostr, const Dictionary& currentWord)
// Overload stream operator << with lhs input (ostr) and rhs input
// (currentWord), which is a Dictionary object. The output prints all the words
// in order from a-z
{
	// Ostr functionalities to be able to print strings to the console
	ios_base::fmtflags currentFlags = ostr.flags();
	char currentFill = ostr.fill();

	// Set fill char to ' ' and enable right justification
	ostr.fill(' ');
	ostr.setf(ios::right, ios::adjustfield);
	ostr << "This is the dictionary: " << endl;

	for (int i = 0; i < currentWord.words.size(); i++)
	//prints all the words
	{
		ostr << currentWord.words[i] << endl;
	}

	// Restore the fill char and the format flags
	ostr.fill(currentFill);
	ostr.setf(currentFlags);

	// Return the output
	return ostr;
}// End << operator overloading

#endif

// End dictionary.h