/*
File Name: heap.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This heap.h file was developed for part b of the Wordsearch project. The main
objective of this file is to implement the logic required of heaps for the
heapSort algoithm. This class was implemented as a template class. 

This class contains:
- A function for identifying the parent node of a heap
- A function for identifying the left node from a parent node of a heap
- A function for identifying the right node from a parent node of a heap
- A function to return the value within a specific node of a heap
- A function to copy values into a heap and carry out the all heap operations
for a MAX-HEAP
- A function to maintain the MAX-Heap properties
- A function to arrange a complete heap as a MAX-HEAP
- A function to properly sort a heap in order from smallest to largest
*/

#ifndef HEAP_CLASS
#define HEAP_CLASS

// Include statements
#include <iostream>
#include <strstream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

using namespace std;

//Template class
template <typename T> 
class Heap
{
	// Public members of Heap Class
	public:
		// Returns parent node of a specific heapNode
		int parent(int heapNode) const;
		
		// Returns left node of a specific parent heapNode
		int left(int heapNode) const;

		// Returns right node of a specific parent heapNode
		int right(int heapNode) const;

		// Returns data contained within specific node of heap
		T getItem(int n) const;

		// Initializes a heap object & converts to MAX-HEAP
		void initalizeMaxHeap(vector<T> values);

		// Maintains the MAX-Heap properties
		void maxHeapify(int node);

		// Builds a MAX-Heap
		void buildMaxHeap();

		// Sorts a MAX-Heap to be in order from smallest to largest values
		vector<T> heapSort();

	// Private members of Heap Class
	private:
		// Vector for storing nodes of heap
		vector<T> h;
};


template <typename T>
int Heap<T>::parent(int heapNode) const
// Returns the index of the parent ndoe for a specific node heapNode
{
	return floor(float(heapNode) / 2);
}// End parent() function


template <typename T>
int Heap<T>::left(int heapNode) const
// Returns the index of the left child node from a specific node heapNode
{
	return (2 * heapNode);
}// End left() function


template <typename T>
int Heap<T>::right(int heapNode) const
// Returns the index of the right child node from a specific node heapNode
{
	return ((2 * heapNode) + 1);
}// End right() function


template <typename T>
T Heap<T>::getItem(int n) const
// Returns the value at a specific position in the vector data member
{
	return h[n];
}// End getItem() function


template <typename T>
void Heap<T>::initalizeMaxHeap(vector<T> values)
// Initializes a heap by passing a vector values into the private data member
// h. Afterwards, the MAX-Heap is built by calling the buildMaxHeap() function
{
	for (int a = 0; a < values.size(); a++)
	// Loops through each vector element to add to the data member
	{
		h.push_back(values[a]);
	}// End for

	// Builds the MAX-Heap
	buildMaxHeap();
}// End initializeMaxHeap() function


template <typename T>
void Heap<T>::maxHeapify(int node)
// Builds a MAX-Heap based on a parent node and up to 2 child nodes (left and
// right). Runs until all values under parent node follow MAX-Heap rules
{
	// Obtain left and right nodes from parent node
	int l = left(node);
	int r = right(node);

	//sets the initial largest to 0
	int largest = 0;

	if (l < h.size() && h[l] > h[node])
	// Check if largest value is left node
	//updates if it has
	{
		largest = l;
	}
	else
	// If not, largest value is parent node
	{
		largest = node;
	}// End if

	if (r <= (h.size() - 1) && h[r] > h[largest])
	// Check if largest value is right node
	{
		largest = r;
	}// End if

	if (largest != node)
	// If the largest node was either the left node or right node...
	{
		// Swap this larger value with the current parent node
		T temp = h[node];
		h[node] = h[largest];
		h[largest] = temp;

		// Call maxHeapify to ensure new parent node still maintains MAX-Heap
		// conditions
		maxHeapify(largest);
	}// End if
}// End maxHeapify() function


template <typename T>
void Heap<T>::buildMaxHeap()
// Builds a MAX-Heap with the maxHeapify() function
{
	for (int z = parent(h.size()); z >= 0; z--)
	// Loops through each parent node from lowest to highest in the heap
	{
		// Calls the maxHeapify function to ensure heap follows MAX-Heap rules
		maxHeapify(z);
	}// End for
}// End buildMaxHeap()


template <typename T>
vector<T> Heap<T>::heapSort()
// Sorts the heap in order from lowest to highest value
{
	// Ensures heap is in MAX-Heap form
	buildMaxHeap();
	
	// Vector for storing sorted heap that is returned
	vector<T> heapCopy(h.size());

	for (int y = (h.size() - 1); y >= 1; y--)
	// Loops through the leaf nodes up to and including the second to last node
	{
		// Swap 1st node with node at y to sort from smallest to largest
		T temp = h[y];
		h[y] = h[0];

		// Copy valeus to a copy vector so that all the sorted values can be
		// returned
		heapCopy[y] = h[0];

		h[0] = temp;

		// Resize the vector with 1 less element to remove largest element
		// and continue sorting the heap
		h.resize(y);

		// Rebuild MAX-Heap by calling maxHeapify() at the root node
		maxHeapify(0);
	}// End for

	// Copy last remaining element in h (lowest value) to first position of
	// heapCopy
	heapCopy[0] = h[0];

	return heapCopy;
}// End heapSort() function


#endif

// End heap.h