/*
File Name: grid.h
Created by: Katherine Cloutier, Yizi Wang, & Zachary Spiegel
Course: EECE2560 Fundamentals of Engineering Algorithms
Semester: Fall 2022

This grid.h file was developed for part b of the Wordsearch project.
This file serves as declaration and implementation of the Grid class,
which reads the letters in the grid from an external file and stores them in a
matrix.

This class contains:
- A constructor that reads the letters in a grid from an external file and 
stores them in a matrix
- A public function numRows that returns the number of rows that the matrix has
- A public function numCols that returns the number of columns that the matrix 
has
- A publicfunction returnGridChar that returns the character in a specific grid
position
- A private data member row that stores the number of rows that the matrix has
- A private data member column that stores the number of columns that the 
matrix has
- A private matrix that stores the letters in the grid from an external file
*/

#ifndef GRID_CLASS
#define GRID_CLASS

// Include statements
#include <iostream>
#include <strstream>
#include <fstream>
#include <string>
#include <stdlib.h>
#include <iomanip>
#include <vector>
#include <ctime>

#include "d_matrix.h"

using namespace std;



class Grid
{
    // Public members of grid Class
    public:
        // Class constructor
        // Reads the letters from a file
        Grid(int r, int c, string filename);

        // Returns number of rows
        int numRows() const;

        // Returns number of columns
        int numCols() const;

        // Returns the character in a specific grid position
        char returnGridChar(int row, int col) const;

    // Private members of grid Class
    private:
        // Stores row number
        int row;

        // Stores column number
        int column;

        // Creates a matrix to store the input letters
        matrix<char> charGrid;
};


Grid::Grid(int r, int c, string fileName)
// Constructor of the Grid class
// Reads letters in the grid from an external file
// and stores them in the class provate matrix charGrid
{
    // Sets row to the input row number
    row = r;

    // Sets column to the input columne number
    column = c;

    // Resizes matrix to required number of rows and columns
    charGrid.resize(r, c);

    // Opens input file
    ifstream fin;
    fin.open(fileName.c_str());

    // Checks if the input file is opened without errors
    if (!fin)
    {
        // error message
        cout << "File opening errors. Please try again.";
    }// End if

    // Stores letters from the input file into the matrix

    // Read matrix size and ignores; need to ignore to properly read grid
    int tmp = 0, tmpOne = 0;
    fin >> tmp >> tmpOne;

    // for loop that goes through each row
    for (int i = 0; i < r; i++)
    {
        // for loop that goes through each column
        for (int j = 0; j < c; j++)
        {
            // Stores the letter from the input file into the corresponding
            // position in the matrix
            // Add 1 to row to account for 1st row declaring matrix size
            fin >> charGrid[i][j];
        }// End c for loop
    }// End r for loop

    // Closes the file
    fin.close();
}// End Grid Constructor


int Grid::numRows() const
// Returns number of rows
{
    return row;
}


int Grid::numCols() const
// Returns number of columns
{
    return column;
}


char Grid::returnGridChar(int row, int col) const
// Returns specific character within grid matrix
{
    return charGrid[row][col];
}


#endif

// End grid.h